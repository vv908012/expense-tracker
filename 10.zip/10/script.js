
// scripts.js

// Load stored expenses and next service date when the page loads
document.addEventListener("DOMContentLoaded", () => {
    displayExpenses();
    displayNextService();
});

// Function to add an expense
document.getElementById("expenseForm").addEventListener("submit", function(e) {
    e.preventDefault();  // Prevents form from submitting the traditional way

    const date = document.getElementById("date").value;
    const description = document.getElementById("description").value;

    const amount = parseFloat(document.getElementById("amount").value);

    // Ensure all fields are filled
    if (!date || !description || isNaN(amount)) {
        alert("Please fill in all fields correctly.");
        return;
    }

    const expense = { date, description, amount };
    saveExpense(expense);
    displayExpenses();

    // Clear form fields
    document.getElementById("expenseForm").reset();
});


// Save expense to local storage
function saveExpense(expense) {
    try {
        let expenses = JSON.parse(localStorage.getItem("expenses")) || [];
        expenses.push(expense);
        localStorage.setItem("expenses", JSON.stringify(expenses));
    } catch (error) {
        console.error("Error saving expense:", error);
    }
}

// Display expenses
function displayExpenses() {
    try {
        const expenses = JSON.parse(localStorage.getItem("expense

s")) || [];
        const expenseList = document.getElementById("expenseList");
        expenseList.innerHTML = ""; // Clear current list

        expenses.forEach((expense, index) => {
            const li = document.createElement("li");
            li.textContent = `${expense.date} - ${expense.description}: $${expense.amount.toFixed(2)}`;
            expenseList.appendChild(li);
        });
    } catch (error) {
        console.error("Error displaying expenses:", error);
    }
}

// Function to schedule the next service
function scheduleService() {
    const serviceDate = document.getElementById("serviceDate").value;
    if (!serviceDate) {
        alert("Please select a date for the next service.");
        return;
    }

    try {
        localStorage.setItem("nextServiceDate", serviceDate);
        displayNextService();
    } catch (error) {
        console.error("Error scheduling service:", error);
    }
}


// Display next scheduled service
function displayNextService() {
    try {
        const serviceDate = localStorage.getItem("nextServiceDate");
        const nextServiceElement = document.getElementById("nextService");

        if (serviceDate) {
            nextServiceElement.textContent = `Next Service Scheduled on: ${new Date(serviceDate).toDateString()}`;
        } else {
            nextServiceElement.textContent = "No service scheduled.";
        }
    } catch (error) {
        console.error("Error displaying next service:", error);
    }

}
